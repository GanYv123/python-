#直方图 茎叶图绘制
#MyGUI.py
import numpy as np
import matplotlib.pyplot as plt

class Draw_Data:
    def __init__(self,stu_dicts) -> None:
        self.stu_dict = stu_dicts # {name: {'score': score, 'point': point}}

    def show_histogram(self):
        names = list(self.stu_dict.keys())
        scores = [info['score'] for info in self.stu_dict.values()]
        gpa = [info['point'] for info in self.stu_dict.values()]

        fig, ax1 = plt.subplots(figsize=(10, 6))  # 创建一个图形

        # 绘制成绩柱状图
        ax1.bar(names, scores, color='skyblue', label='Score')
        ax1.set_xlabel('Student Name')
        ax1.set_ylabel('Score')
        ax1.set_title('Score and GPA')
        ax1.tick_params(axis='x', rotation=45)  # 旋转x轴标签，以防止重叠
        ax1.legend(loc='upper left')

        # 创建第二个y轴，用于绘制绩点折线图
        ax2 = ax1.twinx()
        ax2.plot(names, gpa, color='orange', marker='o', label='GPA')
        ax2.set_ylabel('GPA')
        ax2.legend(loc='upper right')

        plt.tight_layout()  # 自动调整布局
        plt.show()

    def close_histogram(self):
        # 关闭图形
        print("关闭直方图")
        plt.close()

    def show_stem_leaf(self):
        # 使用茎叶图显示成绩
        for name, info in self.stu_dict.items():
            score = info['score']
            # 将分数分解为十位和个位
            tens = score // 10
            ones = score % 10
            # 显示茎叶图
            plt.stem([tens], [ones], linefmt=':', markerfmt='o', basefmt=' ')
            plt.xlabel('Stems')
            plt.ylabel('Leaves')
            plt.title('Stem and Leaf Plot of Scores')
            plt.show()